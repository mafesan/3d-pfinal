/** 
 *
 * Clase principal de la práctica final de Gráficos y Visualización 3D
 * Grado ISAM, curso 2014-2015
 * Aeropuerto, 
 * @author Miguel Ángel Fernández Sánchez
 *
 **/

package pfinal;

//Imports de mis clases
import static org.lwjgl.opengl.GL13.GL_TEXTURE0;
import static org.lwjgl.opengl.GL13.GL_TEXTURE1;
import static org.lwjgl.opengl.GL13.GL_TEXTURE2;
import static org.lwjgl.opengl.GL13.GL_TEXTURE3;
import static org.lwjgl.opengl.GL13.GL_TEXTURE4;
import static org.lwjgl.opengl.GL13.glActiveTexture;
import static org.lwjgl.opengl.GL20.glUniform1f;
import static org.lwjgl.opengl.GL20.glUniform3f;
import static org.lwjgl.opengl.GL20.glUniform4f;
import pfinal.MainAeropuerto;
import pfinal.Avion;
import pfinal.Pista;
import pfinal.Suelo;
import pfinal.Torre;
import pfinal.Terminal;
import pfinal.Sol2;
import Utils.Drawable;
import Utils.OpenGLHelper;
import Utils.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

//Imports de OpenGL
import Utils.*;

public class MainAeropuerto implements Drawable {
	
	//Inicializo variables de OpenGL
	private ShaderProgram shaderProgram;
    private final OpenGLHelper openGLHelper = new OpenGLHelper("pfinal", new FPCameraController(-40, -5, -20));
    
  //Inicializo mis variables

    //Array donde irán metidos todos los objetos dibujables
    private Dibujable misDibujables[] = new Dibujable[12];
    //Objetos que voy a dibujar
    private Terminal miTerminal;
    private Torre supTorre;
    private Torre torreControl;
    private Pista pistaPpal;
    private Pista pistaSec;
    private Avion miAvion1;
    private Avion miAvion2;
    private Avion miAvion3;
    private Avion miAvion4;
    private Suelo miSuelo;
    private Pista pistaAux;
    private Sol2 miSol2;
    
    // Variables de control
    private float velocidadLenta = 0.15f;
    private float velocidadMedia = 0.4f;
    private boolean torreMueve = true;
    private final int elemDib = 12;
    private final int finDex = elemDib - 1;
    private Texture textura1;
    
    private int uniModel;
    private int uNMatrixAttribute;

    private final CubeModel cubeModel = new CubeModel();
    private final SphereModel sphereModel = new SphereModel();
    private final PlaneModel planeModel = new PlaneModel(5, 5);
    private final PlaneModel roadModel = new PlaneModel(5, 1);

    private int cubeVao, axiesVao, sphereVao, planeVao, roadVao;
    private int uKdAttribute;
    private int uKaAttribute;
    private int useTextures;
    private int uniTex1, uniTex2, uniTex3;

    private Texture carretera1, carretera2, cristal1, cristal2, marte;
    
    
    public void initLights() {
    	shaderProgram = openGLHelper.getShaderProgram();
    	int uLightPositionAttribute = shaderProgram.getUniformLocation("LightPosition");
    	int uLightIntensityAttribute = shaderProgram.getUniformLocation("LightIntensity");
    	
    	int uKaAttribute = shaderProgram.getUniformLocation("Ka");
    	int uKdAttribute = shaderProgram.getUniformLocation("Kd");
    	int uKsAttribute = shaderProgram.getUniformLocation("Ks");

    	int uShininessAttribute = shaderProgram.getUniformLocation("Shininess");
    	
    	glUniform4f(uLightPositionAttribute, 2.0f, 4.0f, 2.0f, 1.0f);
        glUniform3f(uLightIntensityAttribute, 0.7f, 0.7f, 0.7f);

        glUniform3f(uKaAttribute, 1.0f, 1.0f, 1.0f);
        glUniform3f(uKdAttribute, 0.8f, 0.8f, 0.8f);
        glUniform3f(uKsAttribute, 0.2f, 0.2f, 0.2f);

        glUniform1f(uShininessAttribute, 18.0f);
    	
    }
    
    private void initObjects() {
    	
      //Clase que instancia los objetos
    	
    	
    	
		shaderProgram = openGLHelper.getShaderProgram();  
		miSuelo = new Suelo();
		  
		pistaPpal = new Pista();

		
		

		pistaSec = new Pista();

		  
		pistaAux = new Pista();

		  
		miTerminal = new Terminal();
		miTerminal.setTexture("glass.jpg");
		  
		supTorre = new Torre();
		supTorre.setTexture("glass2.jpg");
		  
		torreControl = new Torre();
		torreControl.setTexture("blackmetal.jpg");
		  
		miAvion1 = new Avion();
		miAvion2 = new Avion();
		miAvion3 = new Avion();
		miAvion4 = new Avion();
	  
		miSol2 = new Sol2();
	}

    private void prepareBuffers() {
        shaderProgram = openGLHelper.getShaderProgram();              
    }

    @Override
    public void draw()
    {
    	// Método que llama al procedimiento que dibuja.
    	angle += angularVelocity * openGLHelper.getDeltaTime();
        
        
        drawFloor();
        /*drawAxies();
        drawRoad();
        drawModel1();
        drawModel2();
        drawModel3();*/
        drawSomeModel();
    }
    
    

 
    private void drawSomeModel() {
    	// Clase que da a los objetos dibujables sus atributos pincipales
        // tales como: posición inicial, rotación, escala, textura, etc.
    	
    	shaderProgram = openGLHelper.getShaderProgram();
    	
    	//=========== Suelo ===========//
    	miSuelo.setRotation(0.0f, 0.0f, 1f, 0);
    	miSuelo.setPosition(10,0,0);
    	miSuelo.setScale(50.0f, 1.0f, 50.0f);

    	//=========== Pista principal ===========//
    	pistaPpal.setRotation(0.0f, 0.0f, 1f, 0);
    	pistaPpal.setPosition(10, 0.1f, 0.0f);
    	pistaPpal.setScale(50.0f, 1.0f, 6.0f);

    	//=========== Pista secundaria ===========//
    	pistaSec.setRotation(90.0f, 0.0f, 1f, 0.0f);
    	pistaSec.setPosition(10.0f, 0.1f, 21.0f);
    	pistaSec.setScale(5.0f, 1.0f, 15.0f);

    	//=========== Pista auxiliar ===========//
    	pistaAux.setRotation(90.0f, 0.0f, 1f, 0.0f);
    	pistaAux.setPosition(-8.0f, 0.1f, -21.0f);
    	pistaAux.setScale(5.0f, 1.0f, 15.0f);
    	
    	//=========== Terminal ===========//
    	miTerminal.setRotation(0.0f, 0.0f, 1f, 0);
    	miTerminal.setPosition(25, 0.0f, -35.0f);
    	miTerminal.setScale(10.0f, 7.0f, 7.0f);
    	
    	//=========== Torre Control ===========//
  	      // Parte Superior
    	supTorre.setRotation(0.0f, 0.0f, 1f, 0.0f, torreMueve);
    	supTorre.setPosition(8, 10.0f, -35.0f);
    	supTorre.setScale(2.0f, 1.0f, 2.0f);
    	  // Parte troncal
    	torreControl.setRotation(0.0f, 0.0f, 1f, 0);
    	torreControl.setPosition(8, 0.0f, -35.0f);
    	torreControl.setScale(1.0f, 10.0f, 1.0f);

    	//=========== Avión 1 (Pista) ===========//
		miAvion1.setRotation(270.0f, 0.0f, 1f, 0);
		miAvion1.setPosition(-50, 1.0f, 0.0f, velocidadLenta);
		miAvion1.setScale(0.0018f, 0.0018f, 0.0018f);
		
		//=========== Avión 2 (Volando)===========//
		miAvion2.setRotation(270f, 0.0f, 1f, 0);
		miAvion2.setPosition(-50, 8.0f, -14.0f, velocidadMedia);
		miAvion2.setScale(0.0015f, 0.0015f, 0.0015f);

		//=========== Avión 3 (Aparcado, izda Terminal ===========//
        miAvion3.setRotation(180f, 0.0f, 1f, 0);
		miAvion3.setPosition(47, 3f, -30.0f, 0.0f);
		miAvion3.setScale(0.003f, 0.003f, 0.003f);

    	//=========== Avión 4 (Aparcado)===========//
    	miAvion4.setRotation(0f, 0.0f, 1f, 0);
		miAvion4.setPosition(-15, 3f, 25.0f, 0.0f);
		miAvion4.setScale(0.004f, 0.004f, 0.004f);
		
		//======= Array de dibujables ========//
		misDibujables[0] = miAvion1;
		misDibujables[1] = miAvion2;
		misDibujables[2] = miSuelo;
		misDibujables[3] = pistaPpal;
		misDibujables[4] = miTerminal;
		misDibujables[5] = torreControl;
		misDibujables[6] = supTorre;
		misDibujables[7] = pistaSec;
		misDibujables[8] = miAvion3;
		misDibujables[9] = miAvion4;
		misDibujables[10] = pistaAux;
		misDibujables[11] = miSol2;
		
		// Aplicamos polimorfismo dibujando todos los elementos del array de dibujables.
		for(int dex = 0; dex <= finDex; dex++) {
        	misDibujables[dex].prepararBuffers(openGLHelper);
            misDibujables[dex].dibujar(openGLHelper);
        }
    }

    private float angle;
    private static final float angularVelocity = 10.f;

    private void drawModel1() {
        shaderProgram.setUniform(uniTex1, marte.getId() -1);
        glBindVertexArray(cubeVao);
        glUniform3f(uKaAttribute, 1.0f, 1.0f, 1.0f);
        glUniform3f(uKdAttribute, 0.8f, 0.8f, 0.8f);
        glUniform1i(useTextures, 1);

        Matrix4f model = Matrix4f.rotate(angle, 0.5f, 1f, 0);
        model = Matrix4f.scale(2.0f, 2.0f, 2.0f).multiply(model);
        model = Matrix4f.translate(-1, 4, -3).multiply(model);
        glUniformMatrix4(uniModel, false, model.getBuffer());

        Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
        normalMatrix.transpose();
        glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());

        glDrawElements(GL_TRIANGLES, cubeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
    }

    private void drawModel2() {
        shaderProgram.setUniform(uniTex1, marte.getId() -1);

        glBindVertexArray(cubeVao);
        glUniform3f(uKaAttribute, 1.0f, 1.0f, 1.0f);
        glUniform3f(uKdAttribute, 0.8f, 0.8f, 0.8f);
        glUniform1i(useTextures, 1);

        Matrix4f model = Matrix4f.rotate(angle, 0.5f, 1f, 0);
        model = Matrix4f.scale(2.0f, 2.0f, 2.0f).multiply(model);
        model = Matrix4f.translate(6, 3, 0).multiply(model);
        glUniformMatrix4(uniModel, false, model.getBuffer());

        Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
        normalMatrix.transpose();
        glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());

        glDrawElements(GL_TRIANGLES, cubeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
    }

    private void drawModel3() {
        glBindVertexArray(sphereVao);
        glUniform3f(uKaAttribute, 0.8f, 0.2f, 0.5f);
        glUniform3f(uKdAttribute, 0.8f, 0.2f, 0.5f);
        glUniform1i(useTextures, 0);

        Matrix4f model = Matrix4f.scale(6.0f, 1.0f, 1.0f);
        model = Matrix4f.translate(5.0f*(1.2f + (float)Math.cos(angle/10)), 4, 3).multiply(model);
        glUniformMatrix4(uniModel, false, model.getBuffer());

        Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
        normalMatrix.transpose();
        glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());

        glDrawElements(GL_TRIANGLES, sphereModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
    }

    private void drawAxies() {
        glBindVertexArray(axiesVao);
        glUniform1i(useTextures, 0);

        for (int i = 0; i < 20; i++) {
            Matrix4f model = Matrix4f.scale(0.35f, 0.15f, 0.15f);
            model = Matrix4f.translate(i, 0, 0).multiply(model);
            glUniformMatrix4(uniModel, false, model.getBuffer());
            Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
            normalMatrix.transpose();
            glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());
            glUniform3f(uKaAttribute, 0.9f, 0.0f, 0.0f);
            glUniform3f(uKdAttribute, 0.9f, 0.0f, 0.0f);
            glDrawElements(GL_TRIANGLES, cubeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);

            model = Matrix4f.scale(0.15f, 0.35f, 0.15f);
            model = Matrix4f.translate(0, i, 0).multiply(model);
            glUniformMatrix4(uniModel, false, model.getBuffer());
            normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
            normalMatrix.transpose();
            glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());
            glUniform3f(uKaAttribute, 0.0f, 0.9f, 0.0f);
            glUniform3f(uKdAttribute, 0.0f, 0.9f, 0.0f);
            glDrawElements(GL_TRIANGLES, cubeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);

            model = Matrix4f.scale(0.15f, 0.15f, 0.35f);
            model = Matrix4f.translate(0, 0, 0 + i).multiply(model);
            glUniformMatrix4(uniModel, false, model.getBuffer());
            normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
            normalMatrix.transpose();
            glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());
            glUniform3f(uKaAttribute, 0.0f, 0.0f, 0.9f);
            glUniform3f(uKdAttribute, 0.0f, 0.0f, 0.9f);
            glDrawElements(GL_TRIANGLES, cubeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
        }
    }
     private void drawFloor() {
        
        shaderProgram.setUniform(uniTex1, marte.getId() -1);
        glBindVertexArray(planeVao);
        glUniform3f(uKaAttribute, 1.0f, 1.0f, 1.0f);
        glUniform3f(uKdAttribute, 1.0f, 1.0f, 1.0f);
        glUniform1i(useTextures, 1);

        Matrix4f model = Matrix4f.scale(1.0f, 1.0f, 1.0f);
        model = Matrix4f.translate(10, 3, 0).multiply(model);
        glUniformMatrix4(uniModel, false, model.getBuffer());

        Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
        normalMatrix.transpose();
        glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());

        glDrawElements(GL_TRIANGLES, planeModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
    }
     
    private void drawRoad() {
        
        shaderProgram.setUniform(uniTex1, marte.getId() -1);
        glBindVertexArray(roadVao);
        glUniform3f(uKaAttribute, 1.0f, 1.0f, 1.0f);
        glUniform3f(uKdAttribute, 1.0f, 1.0f, 1.0f);
        glUniform1i(useTextures, 1);

        Matrix4f model = Matrix4f.scale(10.0f, 1.0f, 2.0f);
        model = Matrix4f.translate(10, 0, 0).multiply(model);
        glUniformMatrix4(uniModel, false, model.getBuffer());

        Matrix3f normalMatrix = model.multiply(openGLHelper.getViewMatrix()).toMatrix3f().invert();
        normalMatrix.transpose();
        glUniformMatrix3(uNMatrixAttribute, false, normalMatrix.getBuffer());
        // Enable polygon offset to resolve depth-fighting isuses
        glEnable(GL_POLYGON_OFFSET_FILL);
        glPolygonOffset(-2.0f, 4.0f);
        glDrawElements(GL_TRIANGLES, roadModel.getIndicesLength(), GL_UNSIGNED_INT, 0);
        glDisable(GL_POLYGON_OFFSET_FILL);
    }
    
    private void prepareModels() {
       // --------------------- AXIES MODEL  -------------------------------//
        shaderProgram = openGLHelper.getShaderProgram();
        int posAttrib = shaderProgram.getAttributeLocation("aVertexPosition");
        int vertexNormalAttribute = shaderProgram.getAttributeLocation("aVertexNormal");
        int texCoordsAttribute = shaderProgram.getAttributeLocation("aVertexTexCoord");
        
        uniModel = shaderProgram.getUniformLocation("model");
        uNMatrixAttribute = shaderProgram.getUniformLocation("uNMatrix");
        useTextures = shaderProgram.getUniformLocation("useTextures");
        /*
        axiesVao = glGenVertexArrays();
        glBindVertexArray(axiesVao);

        int vbo_v = cubeModel.createVerticesBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_v);
        glEnableVertexAttribArray(posAttrib);
        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, 0);

        int vbo_n = cubeModel.createNormalsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
        glEnableVertexAttribArray(vertexNormalAttribute);
        glVertexAttribPointer(vertexNormalAttribute, 3, GL_FLOAT, false, 0, 0);

        int ebo = cubeModel.createIndicesBuffer();
        glBindVertexArray(0);

        

        // ----------------------- CUBE MODEL -----------------------------//
        cubeVao = glGenVertexArrays();
        glBindVertexArray(cubeVao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo_v);
        glEnableVertexAttribArray(posAttrib);
        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, 0);

        glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
        glEnableVertexAttribArray(vertexNormalAttribute);
        glVertexAttribPointer(vertexNormalAttribute, 3, GL_FLOAT, false, 0, 0);

        int vbo_t = cubeModel.createTextCoordsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_t);
        glEnableVertexAttribArray(texCoordsAttribute);
        glVertexAttribPointer(texCoordsAttribute, 2, GL_FLOAT, false, 0, 0);

        ebo = cubeModel.createIndicesBuffer();
		*/
        glActiveTexture(GL_TEXTURE0);
		carretera1 = Texture.loadTexture("road.jpg");
		uniTex1 = shaderProgram.getUniformLocation("Texture1");
		shaderProgram.setUniform(uniTex1, 0);
		
		glActiveTexture(GL_TEXTURE1);
		carretera2 = Texture.loadTexture("road2.jpg");
		
		glActiveTexture(GL_TEXTURE2);
		cristal1 = Texture.loadTexture("glass.jpg");
		
		glActiveTexture(GL_TEXTURE3);
		cristal2 = Texture.loadTexture("glass2.jpg");
		
		glActiveTexture(GL_TEXTURE4);
		marte = Texture.loadTexture("mars.jpg");
        /*
        // ----------------------- SPHERE MODEL -----------------------------//
        sphereVao = glGenVertexArrays();
        glBindVertexArray(sphereVao);

        vbo_v = sphereModel.createVerticesBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_v);
        glEnableVertexAttribArray(posAttrib);
        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, 0);

        vbo_n = sphereModel.createNormalsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
        glEnableVertexAttribArray(vertexNormalAttribute);
        glVertexAttribPointer(vertexNormalAttribute, 3, GL_FLOAT, false, 0, 0);

        ebo = sphereModel.createIndicesBuffer();
        glBindVertexArray(0);
        */
        // ----------------------- PLANE MODEL -----------------------------//
        /*planeVao = glGenVertexArrays();
        glBindVertexArray(planeVao);

        int vbo_v = planeModel.createVerticesBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_v);
        glEnableVertexAttribArray(posAttrib);
        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, 0);

        int vbo_n = planeModel.createNormalsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
        glEnableVertexAttribArray(vertexNormalAttribute);
        glVertexAttribPointer(vertexNormalAttribute, 3, GL_FLOAT, false, 0, 0);

        int vbo_t = planeModel.createTextCoordsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_t);
        glEnableVertexAttribArray(texCoordsAttribute);
        glVertexAttribPointer(texCoordsAttribute, 2, GL_FLOAT, false, 0, 0);

        int ebo = planeModel.createIndicesBuffer();
        glBindVertexArray(0);*/
        /*
        // ----------------------- ROAD MODEL -----------------------------//
        roadVao = glGenVertexArrays();
        glBindVertexArray(roadVao);

        vbo_v = roadModel.createVerticesBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_v);
        glEnableVertexAttribArray(posAttrib);
        glVertexAttribPointer(posAttrib, 3, GL_FLOAT, false, 0, 0);

        vbo_n = roadModel.createNormalsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_n);
        glEnableVertexAttribArray(vertexNormalAttribute);
        glVertexAttribPointer(vertexNormalAttribute, 3, GL_FLOAT, false, 0, 0);

        vbo_t = roadModel.createTextCoordsBuffer();
        glBindBuffer(GL_ARRAY_BUFFER, vbo_t);
        glEnableVertexAttribArray(texCoordsAttribute);
        glVertexAttribPointer(texCoordsAttribute, 2, GL_FLOAT, false, 0, 0);

        ebo = roadModel.createIndicesBuffer();
        glBindVertexArray(0);*/
        
    }
    
    public void run() {
        // Método principal que ejecuta los submétodos principales
        System.out.println("Inciando Aeropuerto...");
        openGLHelper.initGL("VS_ADS_Texture.vs", "FS_ADS_Texture4.fs");
        //openGLHelper.initGL("VS_Texture.vs", "FS_Texture.fs");
        prepareModels();
        initLights();
        initObjects();
        prepareBuffers();
        openGLHelper.run(this);
    }
    
    public static void main(String[] args) {
        new MainAeropuerto().run();
    }
  
}

